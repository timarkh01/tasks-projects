import random

int_list = random.sample(range(1, 200), 5)
print(int_list)


#region comb_sort
'''сортировка расческой'''
def comb_sort(ls):
    step = len(ls)
    while step != 1:
        if step != 1:
            step = int(step / 1.25)
        i = 0
        while i + step < len(ls):
            if ls[i] > ls[i + step]:
                ls[i], ls[i + step] = ls[i + step], ls[i]
            i += 1

# comb_sort(int_list)
#endregion


#region insertion_sort
'''сортировка вставками - рассматривается каждый элемент и вставляется в нужное место'''
def insertion_sort(ls):
    for i in range(len(ls)):
        key = ls[i]
        j = i - 1
        while j >= 0 and ls[j] > key:
            ls[j + 1] = ls[j]
            j -= 1
        ls[j + 1] = key

# insertion_sort(int_list)
#endregion


#region selection_sort
'''сортировка выбором - находим min элемент среди оставшихся и вставляем после предыдущего min'''
def selection_sort(ls):
    n = len(ls)
    for i in range(n - 1):
        minim_index = i
        for j in range(i + 1, n):
            if ls[j] < ls[minim_index]:
                minim_index = j
        ls[i], ls[minim_index] = ls[minim_index], ls[i]
    
# selection_sort(int_list)
#endregion


#region shell_sort
'''сортировка Шелла - сравниваем элементы на расстоянии шага и уменьшаем шаг'''
def shell_sort(ls):
    n = len(ls)
    step = n // 2
    while step > 0:
        for i in range(step, n):
            numb = ls[i]
            j = i
            while j >= step and ls[j - step] > numb:
                ls[j] = ls[j - step]
                j -= step
            ls[j] = numb
        step = step // 2

# shell_sort(int_list)
#endregion


#region radix_sort
'''поразрядная сортровка - сравнивем по первому индексу, второму и тд'''
def radix_sort(ls):
    max_len = max([len(str(x)) for x in ls])
    for i in range(max_len):
        cells = [[] for i in range(10)]
        for x in ls:
            digit = (x // 10 ** i) % 10
            cells[digit].append(x)
        ls[:] = [x for j in cells for x in j]

# radix_sort(int_list)
#endregion


#region heap_sort
'''пирамидальная сортировка - испольщзуем бинарное сортирующее дерево (при втором for меняем max на min)'''
def heap_sort(ls):
    n = len(ls) 
    for i in range(n // 2 - 1, -1, -1):
        changing(ls, n, i)
    for i in range(n - 1, 0, -1):
        ls[0], ls[i] = ls[i], ls[0] 
        changing(ls, i, 0)


def changing(ls, n, i):
    largest = i 
    l = 2 * i + 1 
    r = 2 * i + 2  
    if l < n and ls[l] > ls[largest]:
        largest = l
    if r < n and ls[r] > ls[largest]:
        largest = r
    if largest != i:
        ls[i], ls[largest] = ls[largest], ls[i] 
        changing(ls, n, largest)

# heap_sort(int_list)
#endregion   


#region merge_sort
'''сортировка слиянием - делим список попалам пока не получим один список из двух элементов,
затем сравниваем 2 элемента, соединяем два массива по два элемента и сравниваем 4 элемента и тд'''
def merge_sort(arr, left, right):
    if left < right:
        mid = (left + right) // 2
        merge_sort(arr, left, mid)
        merge_sort(arr, mid + 1, right)
        merge(arr, left, mid, right)

def merge(arr, left, mid, right):
    n1 = mid - left + 1
    n2 = right - mid
    L = [0] * n1
    R = [0] * n2
    for i in range(n1):
        L[i] = arr[left + i]
    for j in range(n2):
        R[j] = arr[mid + 1 + j] 
    i = 0  
    j = 0  
    k = left  
    while i < n1 and j < n2:
        if L[i] <= R[j]:
            arr[k] = L[i]
            i += 1
        else:
            arr[k] = R[j]
            j += 1
        k += 1
    while i < n1:
        arr[k] = L[i]
        i += 1
        k += 1
    while j < n2:
        arr[k] = R[j]
        j += 1
        k += 1

# merge_sort(int_list, 0, len(int_list) - 1)
#endregion


#region quick_sort
'''быстрая сортировка - берем опорный элемент и делим массив на меньше и не меньше, и выполняем рекурсию на новых массивах'''
def quick_sort(arr):
    if len(arr) <= 1:
        return arr  
    pivot = arr[len(arr) // 2]  
    left = [x for x in arr if x < pivot] 
    middle = [x for x in arr if x == pivot]  
    right = [x for x in arr if x > pivot] 
    return quick_sort(left) + middle + quick_sort(right)

#print(quick_sort(int_list))
#endregion


#region polyphase_sort
import heapq

def polyphase_sort(input_file, output_file, chunk_size=10):
    chunks = []
    with open(input_file, 'r') as f:
        chunk = []
        for line in f:
            chunk.append(int(line.strip()))
            if len(chunk) >= chunk_size:
                chunk.sort()
                chunks.append(chunk)
                chunk = []
        if chunk:
            chunk.sort()
            chunks.append(chunk)

    with open(output_file, 'w') as out_f:
        iterators = [iter(chunk) for chunk in chunks]
        heap = []
        for i, iterator in enumerate(iterators):
            value = next(iterator)
            heapq.heappush(heap, (value, i))

        while heap:
            value, chunk_idx = heapq.heappop(heap)
            out_f.write(f"{value}\n")
            try:
                next_value = next(iterators[chunk_idx])
                heapq.heappush(heap, (next_value, chunk_idx))
            except StopIteration:
                pass

with open("input_p.txt", 'w') as f:
    for num in int_list:
        f.write(f"{num}\n")

polyphase_sort("input_p.txt", "output_p.txt", chunk_size=10)

#endregion

#print(int_list)