def Replacement(stack, index, res):
    stack.pop(index - 1)
    stack.pop(index - 1)
    stack.pop(index - 1)
    stack.insert(index - 1, res)
    index = index - 1

    return stack, index

def FirstImportance(stack, index, CheckingSymbols):
    while stack[index] != CheckingSymbols:
        if stack[index] == "*":
            res = float(stack[index - 1]) * float(stack[index + 1])
            stack, index = Replacement(stack, index, res)
        if stack[index] == "/":
            num = stack[index + 1]
            if num == "0": 
                raise ValueError("Нельзя делить на 0")
            res = float(stack[index - 1]) / float(num)
            stack, index = Replacement(stack, index, res)
        index += 1

    return stack

def SecondImportance(stack, index, CheckingSymbols):
    while stack[index] != CheckingSymbols:
        if stack[index] == "+":
            res = float(stack[index - 1]) + float(stack[index + 1])
            stack, index = Replacement(stack, index, res)
        if stack[index] == "-":
            res = float(stack[index - 1]) - float(stack[index + 1])
            stack, index = Replacement(stack, index, res)
        index += 1
    
    return stack

def BracketCheck(stack, index):
    while stack[index] != "(": 
        index -= 1
    #print(stack)
    stack = FirstImportance(stack, index, ")")
    stack = SecondImportance(stack, index, ")")
    #print(stack)
    while stack[index] != ")":
        index += 1
    stack.pop(index - 2)
    stack.pop(index - 1)
    return stack


def MathCheck(str):
    stack = []
    sym = ""
    for i in str:
        #print(stack, sym)
        if i == ")":
            if sym != "":
                stack.append(sym)
                sym = ""
                stack.append(i)
            else:
                stack.append(i)
            stack = BracketCheck(stack, stack.index(i))
            continue

        if i in "0123456789":
            sym += i
        elif sym == "":
            stack.append(i)
        else:
            stack.append(sym)
            sym = ""
            stack.append(i)

    index = 0
    stack = FirstImportance(stack, index, "=")
    stack = SecondImportance(stack, index, "=")

    return stack[0]


print(MathCheck("((9-5)*6)/12="))