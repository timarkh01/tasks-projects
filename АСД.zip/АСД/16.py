from queue import LifoQueue

class Node:
    def __init__(self, key):
        self.left = None
        self.right = None
        self.val = key

    def traverseNonRecursive(self):
        stack = LifoQueue()
        stack.put(self)
        while not stack.empty():
            current = stack.get()
            while current:
                print(current.val, end=' ')
                if current.left:
                    stack.put(current.left)
                current = current.right


def find_right_subtree(string, start, end):
    bracket_counter = -1
    while True:
        if (start >= end): 
            return -1
        if ((string[start] == ',') and (bracket_counter == 0)): 
            return start
        if string[start] == '(': 
            bracket_counter += 1
        if string[start] == ')': 
            bracket_counter -= 1
        start += 1

def create_tree(string, start, end):
    while string[start] == ' ' or string[start] == '(': 
        start += 1
    if (start >= end): 
        return
    number = ''
    while string[start] in '1234567890':
        number += string[start]
        start += 1
        if start >= end: 
            return Node(int(number))
    node = Node(int(number))

    right_subtree_index = find_right_subtree(string, start, end)

    if right_subtree_index != -1:
        node.left = create_tree(string, start+1, right_subtree_index)
        node.right = create_tree(string, right_subtree_index+1, end-1)
    else:
        raise ValueError('неправильное выражение')
    return node

input_str = input().strip()
bt = create_tree(input_str, 0, len(input_str))
bt.traverseNonRecursive()
