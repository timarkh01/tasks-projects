class Hash():
    def __init__(self):
        self.item_count = 0 
        self.load_factor = 0.75
        self.volume = 100
        self.table = [None] * self.volume
    
    def insert(self, word):
        if self.checking_not_insert(word, self.table):
            self.item_count += 1
            if self.item_count / len(self.table) > self.load_factor:
                self.table = self.rehash()
    
    def checking_not_insert(self, word, table):
        index = int(hash(word)) % len(table)
        while table[index] != None:
            if table[index] == word:
                return False
            index = (index + 1) % len(table)
        table[index] = word
        return True
    
    def rehash(self):
        self.volume *= 2
        new_table = [None] * self.volume
        for word in self.table:
            if word:
                self.checking_not_insert(word, new_table)
        return new_table
    
    def __str__(self):
        pairs = []
        for i, word in enumerate(self.table):
            if word:
                pairs.append(f'{i}: {word}')
        return '{' + ', '.join(pairs) + "}"

hash_table = Hash()
with open('hash.txt') as input_file:
    for line in input_file:
        for word in line.split():
            hash_table.insert(word)
with open('output.txt', 'w') as output_file:
    output_file.write(str(hash_table))