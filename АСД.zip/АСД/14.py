class Node:
    def __init__(self, key):
        self.key = key
        self.next = None


class Hash:
    def __init__(self, capacity=100, load_factor=0.75):
        self.items_count = 0
        self.load_factor = 0.75
        self.volume = 100
        self.table = [None] * self.volume

    def insert_last(self, index, key, table):
        new_node = Node(key)
        if not table[index]:
            table[index] = new_node
            return True
        current = table[index]
        while current:
            if current.key == key:
                return False
            if not current.next:
                break
            current = current.next
        current.next = new_node
        return True

    def rehash(self):
        self.volume *= 2
        new_table = [None] * self.volume
        for first_key in self.table:
            if first_key:
                key_list = []
                current = first_key
                while current:
                    key_list.append(current.key)
                    if not current.next:
                        break
                    current = current.next
                for node in key_list:
                    index = int(hash(node)) % self.volume
                    self.insert_last(index, node, new_table)
        return new_table

    def insert(self, key):
        index = int(hash(key)) % self.volume
        was_inserted = self.insert_last(index, key, self.table)
        if not was_inserted: return
        self.items_count += 1
        load_factor = self.items_count / self.volume
        if load_factor > self.load_factor:
            self.table = self.rehash()

    def pairs(self):
        pairs = []
        for index, first_node in enumerate(self.table):
            if first_node != None:
                node = first_node
                keys = [node.key]
                while node.next:
                    node = node.next
                    keys.append(node.key)
                pairs.append((index, keys))
        return pairs


    def __str__(self):
        return "{" + ", ".join(map(str, self.pairs())) + "}"

hash_table = Hash()
with open('hash.txt') as input_file:
    for line in input_file:
        for word in line.split():
            hash_table.insert(word)
with open('output_14.txt', 'w') as output_file:
    output_file.write(str(hash_table))