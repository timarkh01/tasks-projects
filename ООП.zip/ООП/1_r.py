from typing import List, Union, Tuple
from functools import total_ordering
from math import pi

T_angle = Union[int, float]
T_anglerange = Union[int, float, 'Angle']

'''придирки: лучше для каждой скобки сделать свой self, а не как у меня self.gaps = [start_gap, finish_gap];
пример лучше писать как у меня для angle_range, т.е. f'{...} + {...} = {... + ...}'.'''

@total_ordering
class Angle:
    def __init__(self, value: T_angle) -> None:
        self.check_right_type_for_values(value)
        self.value = value
        self.is_degrees = True
    
    def change_measurement(self) -> None:
        if self.is_degrees:
            self.value = pi / 180 * self.value
            self.is_degrees =  False
        else:
            self.value = 180 / pi * self.value
            self.is_degrees = True

    def check_right_type_for_values(self, object_check) -> None:
        if type(object_check).__name__ not in ['float', 'int']:
            raise ValueError('Неправильный тип объекта')

    def check_right_type_for_orders(self, object_check) -> None:
        if type(object_check).__name__ != 'Angle':
            raise ValueError('Неправильный тип объекта')

    def value_for_ordering(self, angle: 'Angle') -> T_angle:
        subvalue = angle.value 
        while subvalue >= 360:
            subvalue -= 360
        return subvalue
    
    def check_same_measurement(self, other) -> None:
        if self.is_degrees != other.is_degrees:
            self.change_measurement()

    #region order

    def __eq__(self, other: 'Angle') -> bool:
        self.check_right_type_for_orders(other)
        self.check_same_measurement(other)
        self_value = self.value_for_ordering(self)
        other_value = self.value_for_ordering(other)
        return self_value == other_value
    
    def __lt__(self, other: 'Angle') -> bool:
        self.check_right_type_for_orders(other)
        self.check_same_measurement(other)
        self_value = self.value_for_ordering(self)
        other_value = self.value_for_ordering(other)
        return self_value < other_value

    #endregion

    #region output

    def __float__(self) -> T_angle:
        return float(self.value)
    
    def __int__(self) -> T_angle:
        return int(self.value)
    
    def __str__(self) -> str:
        return str(self.value)
    
    def __repr__(self) -> str:
        return str(self.value)

    #endregion

    #region math

    def __add__(self, other: T_angle) -> 'Angle':
        self.check_right_type_for_values(other)
        return Angle(self.value + other)
    
    def __iadd__(self, other: T_angle) -> 'Angle':
        self.check_right_type_for_values(other)
        self.value += other
        return self

    def __sub__(self, other: T_angle) -> 'Angle':
        self.check_right_type_for_values(other)
        return Angle(self.value - other)
    
    def __isub__(self, other: T_angle) -> 'Angle':
        self.check_right_type_for_values(other)
        self.value -= other
        return self

    def __mul__(self, other: T_angle) -> 'Angle':
        self.check_right_type_for_values(other)
        return Angle(self.value * other)
    
    def __imul__(self, other: T_angle) -> 'Angle':
        self.check_right_type_for_values(other)
        self.value *= other
        return self

    def __truediv__(self, other: T_angle) -> 'Angle':
        self.check_right_type_for_values(other)
        return Angle(self.value / other)
    
    def __itruediv__(self, other: T_angle) -> 'Angle':
        self.check_right_type_for_values(other)
        self.value /= other
        return self

    #endregion

@total_ordering
class AngleRange:
    def __init__(self, start: T_anglerange, finish: T_anglerange, start_gap: bool = True,
                 finish_gap: bool = True) -> None:
        self.check_right_type_for_gaps([start_gap, finish_gap])
        self.gaps = [start_gap, finish_gap]
        self.start, self.finish = self.help_for_init(start, finish)

    def help_for_init(self, start: T_anglerange, finish: T_anglerange) -> Union[None, Tuple[T_angle, T_angle]]:
        if start > finish:
            raise ValueError('Первая точка должна быть меньше второй')
        return self.checking_type_for_points_init(start), self.checking_type_for_points_init(finish)

    def check_right_type_for_gaps(self, object_check: List[bool]):
        if [type(object_check[0]).__name__, type(object_check[1]).__name__] != ['bool', 'bool']:
            raise ValueError('Неправильный тип объекта')

    def check_right_type_for_object(self, object_check: 'AngleRange') -> None:
        if type(object_check).__name__ != 'AngleRange':
            raise ValueError('Неправильный тип объекта')

    def checking_type_for_points_init(self, other: T_anglerange) -> Union[None, T_angle]:
        point = None
        match type(other).__name__:
            case 'Angle':
                point = other.value
            case 'int' | 'float':
                point = other
            case _:
                raise ValueError('Неправильные данные')
        return point

    def __eq__(self, other: 'AngleRange') -> bool:
        self.check_right_type_for_object(other)
        if self.gaps == other.gaps:
            if self.start == other.start and self.finish == other.finish:
                return True
        return False

    def __lt__(self, other: 'AngleRange') -> bool:
       self.check_right_type_for_object(other)
       return self.__abs__() < other.__abs__()

    def output(self) -> str:
        match self.gaps:
            case [True, True]:
                return f'[{self.start}, {self.finish}]'
            case [True, False]:
                return f'[{self.start}, {self.finish})'
            case [False, True]:
                return f'({self.start}, {self.finish}]'
            case [False, False]:
                return f'({self.start}, {self.finish})'
            case _:
                return f'df' # для того чтобы не жаловалось на типизацию
    
    def __str__(self) -> str:
        return self.output()
    
    def __repr__(self) -> str:
        return self.output()
    
    def __abs__(self) -> T_angle:
       return self.start - self.finish
    
    def __contains__(self, other: 'AngleRange') -> bool:
        self.check_right_type_for_object(other)
        if type(other).__name__ == 'AngleRange':
            match self.gaps:
                case [True, True]:
                    return self.start <= other.start and other.finish <= self.finish
                case [True, False]:
                    return self.start <= other.start and other.finish < self.finish
                case [False, True]:
                    return self.start < other.start and other.finish <= self.finish
                case [False, False]:
                    return self.start < other.start and other.finish < self.finish
        else:
            match self.gaps:
                case [True, True]:
                    return self.start <= other <= self.finish
                case [True, False]:
                    return self.start <= other < self.finish
                case [False, True]:
                    return self.start < other <= self.finish
                case [False, False]:
                    return self.start < other < self.finish
        return False # для того чтобы не жаловалось на типизацию

    #region add

    def __add__(self, other: 'AngleRange') -> Union['AngleRange', Tuple['AngleRange', 'AngleRange']]:
        self.check_right_type_for_object(other)
        if self.__contains__(other):
            return self
        elif other.__contains__(self):
            return other
        elif self.finish >= other.start > self.start:
            if self.finish == other.start and [self.gaps[1], other.gaps[0]] == [False, False]:
                return (AngleRange(self.start, self.finish, start_gap=self.gaps[0], finish_gap=self.gaps[1]),
                        AngleRange(other.start, other.finish, start_gap=other.gaps[0], finish_gap=other.gaps[1]))
            else:
                return AngleRange(self.start, other.finish, start_gap=self.gaps[0], finish_gap=other.gaps[1])
        elif self.start <= other.finish < self.finish:
            if self.start == other.finish and [self.gaps[0], other.gaps[1]] == [False, False]:
                return (AngleRange(self.start, self.finish, start_gap=self.gaps[0], finish_gap=self.gaps[1]),
                        AngleRange(other.start, other.finish, start_gap=other.gaps[0], finish_gap=other.gaps[1]))
            else:
                return AngleRange(other.start, self.finish, start_gap=self.gaps[1], finish_gap=other.gaps[0])
        elif self.start == other.start and self.finish == other.finish:
            return AngleRange(self.start, self.finish, start_gap=self.gaps[0] | other.gaps[0],
                              finish_gap=self.gaps[1] | other.gaps[1])
        else:
            return self, other

    #endregion

    # region sub

    def __sub__(self, other: 'AngleRange')-> Union[None, int, float, 'AngleRange', Tuple[int | float, int | float],
                                                   Tuple['AngleRange', 'AngleRange'],
                                                   Tuple[int | float, 'AngleRange'], Tuple['AngleRange',
                                                   int | float]]:
        self.check_right_type_for_object(other)
        if ((other.start <= self.start and other.finish > self.finish) or
            (other.start < self.start and other.finish >= self.finish)):
            return None
        elif self.__contains__(other):
            return self.help_for_sub_contains(other)
        elif other.__contains__(self):
            return other.help_for_sub_contains(self)
        elif self.finish >= other.start > self.start:
            if self.finish == other.start:
                match [self.gaps[1], other.gaps[0]]:
                    case [True, False] | [False, False]:
                        return self
                    case [True, True]:
                        return AngleRange(self.start, self.finish, start_gap=self.gaps[0], finish_gap=False)
                    case [False, True]:
                        return AngleRange(self.start, self.finish, start_gap=self.gaps[0], finish_gap=False)
            else:
                return AngleRange(self.start, other.start, start_gap=self.gaps[0], finish_gap=not other.gaps[0])
        elif self.start <= other.finish < self.finish :
            if self.start == other.finish:
                match [self.gaps[0], other.gaps[1]]:
                    case [False, True] | [False, False]:
                        return other, self
                    case [True, True]:
                        return (AngleRange(other.start, other.finish, start_gap=other.gaps[0], finish_gap=False),
                                AngleRange(self.start, self.finish, start_gap=False, finish_gap=self.gaps[1]))
                    case [True, False]:
                        return (AngleRange(self.start, other.start, start_gap=other.gaps[0], finish_gap=False),
                                AngleRange(other.finish, self.finish, start_gap=False, finish_gap=other.gaps[0]))
            else:
                return (AngleRange(other.start, self.start, start_gap=other.gaps[0], finish_gap=not self.gaps[0]),
                        AngleRange(other.finish, self.finish, start_gap=not other.gaps[1], finish_gap=self.gaps[1]))
        else:
            return self


    def help_for_sub_contains(self, other: 'AngleRange') -> Union[None, int, float, Tuple[int | float, int | float],
                                                                  'AngleRange', Tuple['AngleRange', 'AngleRange'],
                                                                  Tuple[int | float, 'AngleRange'], Tuple['AngleRange',
                                                                  int | float], str]:
        if self.start == other.start and self.finish != other.finish:
            match [self.gaps[0], other.gaps[0]]:
                case [True, False]:
                    return (self.start,
                            AngleRange(other.finish, self.finish, start_gap=not other.gaps[0], finish_gap=not self.gaps[0]))
                case _:
                    return AngleRange(other.finish, self.finish, start_gap=not other.gaps[0], finish_gap=self.gaps[0])
        elif self.start != other.start and self.finish == other.finish:
            match [self.gaps[1], other.gaps[1]]:
                case [True, False]:
                    return (AngleRange(self.start, other.start, start_gap=self.gaps[0], finish_gap=not other.gaps[0]),
                            self.finish)
                case _:
                    return AngleRange(self.start, other.start, start_gap=self.gaps[0], finish_gap=not other.gaps[0])
        elif self.start == other.start and self.finish == other.finish:
            match [self.gaps[0], other.gaps[0], self.gaps[1], other.gaps[1]]:
                case [True, True, True, True]:
                    return None
                case [True, False, True, True]:
                    return self.start
                case [True, True, True, False]:
                    return self.finish
                case [True, False, True, False]:
                    return self.start, self.finish
        return AngleRange(self.start, other.start, start_gap=self.gaps[0], finish_gap=not other.gaps[0]), AngleRange(
            other.finish, self.finish, start_gap= not other.gaps[1], finish_gap= self.gaps[1])

    #endregion

#region examples for Angel

ang1 = Angle(150)
ang2 = Angle(160)
ang3 = Angle(150)

# проверки на сравнения

print(f'{ang1} < {ang2} = {ang1 < ang2}')
print(f'{ang1} == {ang2} = {ang1 == ang2}')
print(f'{ang1} < {ang3} = {ang1 == ang3}')

# проверки на вывод
print(float(ang1))  # 150.0
print(int(ang1))    # 150
print(str(ang1))    # 150
print(ang1)         # 150

# проверки на математические операции
ang1 += 10
print(ang1)         # 160
ang1 -= 10
print(ang1)         # 150
ang1 *= 10
print(ang1)         # 1500
ang1 /= 10
print(ang1)         # 150.0

#endregion

# region examples for AngleRange

angr1 = AngleRange(10, 40)
angr2 = AngleRange(10, 40, start_gap=False)
angr3 = AngleRange(10, 39)
angr4 = AngleRange(10, 40)

# проверки на сравнения

print(f'{angr1} == {angr2} = {angr1 == angr2}')
print(f'{angr1} == {angr3} = {angr1 == angr3}')
print(f'{angr1} == {angr4} = {angr1 == angr4}')
print(f'{angr1} < {angr2} = {angr1 < angr2}')


# проверки на вывод

print(angr1)         # [10, 40]
print(str(angr1))    # [10, 40]

# проверки на содержание одного угла в другом

print(f'{angr1} in {angr2} = {angr1 in angr2}')
print(f'{angr2} in {angr1} = {angr2 in angr1}')
print(f'{angr1} in {angr3} = {angr2 in angr1}')
print(f'{angr1} in {angr4} = {angr2 in angr1}')
print(f'{angr3} in {angr1} = {angr2 in angr1}')

# проверки на сумму

# сумма без пересечений

angr1 = AngleRange(10, 40, start_gap=False, finish_gap=True)
angr2 = AngleRange(50, 90, start_gap=True, finish_gap=False)
print(f'{angr1} + {angr2} = {angr1 + angr2}')

# сумма, когда пересечения происходит в одной точке

angr1 = AngleRange(10, 40, start_gap=True, finish_gap=True)
angr2 = AngleRange(10, 40, start_gap=True, finish_gap=False)
angr3 = AngleRange(40, 50, start_gap=False, finish_gap=True)
angr4 = AngleRange(40, 50, start_gap=True, finish_gap=True)
print(f'{angr1} + {angr3} = {angr1 + angr3}')
print(f'{angr1} + {angr4} = {angr1 + angr4}')
print(f'{angr2} + {angr3} = {angr2 + angr3}')
print(f'{angr2} + {angr4} = {angr2 + angr4}')

# сумма, когда пересечением является отрезок

angr1 = AngleRange(10, 40, start_gap=True, finish_gap=True)
angr2 = AngleRange(30, 50, start_gap=False, finish_gap=True)
print(f'{angr1} + {angr2} = {angr1 + angr2}')


# сумма, когда один отрезок целиком находится в другом

angr1 = AngleRange(10, 40, start_gap=True, finish_gap=True)
angr2 = AngleRange(30, 35, start_gap=False, finish_gap=True)
print(f'{angr1} + {angr2} = {angr1 + angr2}')

# проверки на разность

# разность без пересечений

angr1 = AngleRange(10, 40, start_gap=False, finish_gap=True)
angr2 = AngleRange(50, 90, start_gap=True, finish_gap=False)
print(f'{angr1} - {angr2} = {angr1 - angr2}')

# разность, когда пересечение происходит только в одной точке

angr1 = AngleRange(10, 40, start_gap=True, finish_gap=True)
angr2 = AngleRange(10, 40, start_gap=True, finish_gap=False)
angr3 = AngleRange(40, 50, start_gap=False, finish_gap=True)
angr4 = AngleRange(40, 50, start_gap=True, finish_gap=True)
print(f'{angr1} - {angr3} = {angr1 - angr3}')
print(f'{angr1} - {angr4} = {angr1 - angr4}')
print(f'{angr2} - {angr3} = {angr2 - angr3}')
print(f'{angr2} - {angr4} = {angr2 - angr4}')


# разность, когда пересечением является отрезок

angr1 = AngleRange(10, 40, start_gap=True, finish_gap=True)
angr2 = AngleRange(10, 40, start_gap=True, finish_gap=False)
angr3 = AngleRange(30, 50, start_gap=False, finish_gap=True)
angr4 = AngleRange(30, 50, start_gap=True, finish_gap=True)
print(f'{angr1} - {angr3} = {angr1 - angr3}')
print(f'{angr1} - {angr4} = {angr1 - angr4}')
print(f'{angr2} - {angr3} = {angr2 - angr3}')
print(f'{angr2} - {angr4} = {angr2 - angr4}')


# разность, когда один отрезок входит в другой

angr1 = AngleRange(10, 40, start_gap=True, finish_gap=True)
angr2 = AngleRange(10, 40, start_gap=True, finish_gap=False)
angr3 = AngleRange(30, 35, start_gap=False, finish_gap=True)
angr4 = AngleRange(30, 35, start_gap=True, finish_gap=True)
print(f'{angr1} - {angr3} = {angr1 - angr3}')
print(f'{angr1} - {angr4} = {angr1 - angr4}')
print(f'{angr2} - {angr3} = {angr2 - angr3}')
print(f'{angr2} - {angr4} = {angr2 - angr4}')

angr1 = AngleRange(10, 30, start_gap=True, finish_gap=True)
angr2 = AngleRange(5, 40, start_gap=True, finish_gap=False)
print((angr1 - angr2))

#endregion