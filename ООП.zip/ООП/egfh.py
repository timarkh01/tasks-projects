import json

def read_int_file(filename: str):
    try:
        with open(filename, "r") as file:
            return json.load(file)
    except:
        print('Такого файла нет')

def check_types(color, position, symbol):
    check_type_for_color(color)
    check_type_for_position(position)
    check_type_for_symbol(symbol)

def check_type_for_text(text):
    if not isinstance(text, str):
        raise TypeError('Неправильно введенный текст')

def check_type_for_color(color):
    if not isinstance(color, str):
        raise TypeError('Неправильный цвет, выберете цвет так: Color.GREEN')

def check_type_for_position(position):
    if not isinstance(position[0], int) or not isinstance(position[1], int):
        raise TypeError('Неправильные координаты')

def check_type_for_symbol(symbol):
    if not isinstance(symbol, str):
        raise TypeError('Неправильный символ')
    elif len(symbol) != 1:
        raise TypeError('Символ должен состоять из одной буквы')