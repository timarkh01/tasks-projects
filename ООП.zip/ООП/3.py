from typing import List
from enum import Enum
from abc import ABC, abstractmethod
import socket
import sys
from ftplib import FTP
from datetime import datetime
# from asdf import check_text, check_Protocols

#region check
def check_text(text):
    if not isinstance(text, str):
        raise TypeError('Введите текст')

def check_log_filter_protocol(list_protocol):
    for filter_protocol in list_protocol:
        if not isinstance(filter_protocol, LogFilter):
            raise TypeError('На вход должен подаваться List[LogFilter]')

def check_log_formatter_protocol(list_protocol):
    for formatter in list_protocol:
        if not isinstance(formatter, LogFormatter):
            raise TypeError('На вход должен подаваться List[LogFormatter]')

def check_log_handler_protocol(list_protocol):
    for handler in list_protocol:
        if not isinstance(handler, LogHandler):
            raise TypeError('На вход должен подаваться List[LogHandler]')

def check_protocols(filter_protocol, formatter_protocol, handler_protocol):
    check_log_filter_protocol(filter_protocol)
    check_log_formatter_protocol(formatter_protocol)
    check_log_handler_protocol(handler_protocol)
#endregion


class LogLevel(Enum):
    INFO = 1
    WARN = 2
    ERROR = 3


class LogFilter(ABC):
    @abstractmethod
    def match(self, log_level: LogLevel, text: str) -> bool:
        pass


class LevelFilter(LogFilter):
    def __init__(self, log_level: LogLevel) -> None:
        self.min_value = log_level.value

    def match(self, log_level: LogLevel, text: str) -> bool:
        return log_level.value >= self.min_value


class SimpleLogFilter(LogFilter):
    def __init__(self, pattern: str) -> None:
        check_text(pattern)
        self.pattern = pattern

    def match(self, log_level: LogLevel, text: str) -> bool:
        return self.pattern in text


class ReLogFilter(LogFilter):
    def __init__(self, pattern: str) -> None:
        check_text(pattern)
        self.pattern = pattern.split('|')

    def match(self, log_level: LogLevel, text: str) -> bool:
        check_text(text)
        for pattern in self.pattern:
            if pattern in text:
                return True
        return False


class LogHandler(ABC):
    @abstractmethod
    def handle(self, log_level: LogLevel, text: str) -> None:
        pass


class FileHandler(LogHandler):
    def __init__(self, filename: str) -> None:
        check_text(filename)
        self.filename = filename

    def handle(self, log_level: LogLevel, text: str) -> None:
        check_text(text)
        try:
            with open(self.filename, "a", encoding='utf-8') as f:
                f.write(text + '\n')
        except:
            raise 'Ошибка с файлом'


class SocketHandler(LogHandler):
    def __init__(self, host: str, port: int) -> None:
        check_text(host)
        check_text(port)
        self.host = host
        self.port = port

    def handle(self, log_level: LogLevel, text: str) -> None:
        check_text(text)
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.connect((self.host, self.port))
                s.sendall(text.encode('utf-8'))
        except:
            raise 'Ошибка с Socket'



class ConsoleHandler(LogHandler):
    def handle(self, log_level: LogLevel, text: str) -> None:
        check_text(text)
        print(text)


class SyslogHandler(LogHandler):
    def handle(self, log_level: LogLevel, text: str) -> None:
        check_text(text)
        #syslog.syslog(text)
        sys.stderr.write(text + '\n')


class FtpHandler(LogHandler):
    def __init__(self, ftp_name: str, username: str, password: str) -> None:
        check_text(ftp_name)
        check_text(username)
        check_text(password)
        self.ftp_name = ftp_name
        self.username = username
        self.password = password

    def handle(self, log_level: LogLevel, text: str) -> None:
        check_text(text)
        try:
            txt_name = 'FTP_log.txt'
            with open(txt_name, 'w') as f:
                f.write(text)
            with FTP(self.ftp_name) as ftp:
                ftp.login(self.username, self.password)
                ftp.encoding = 'utf-8'
                with open(txt_name, 'rb') as f:
                    ftp.storbinary(f'STOR {txt_name}', f)
        except:
            raise 'Ошибка с Ftp'


class LogFormatter(ABC):
    @abstractmethod
    def format(self, log_level: LogLevel, text: str) -> str:
        pass


class TextFormatter(LogFormatter):
    def format(self, log_level: LogLevel, text: str) -> str:
        check_text(text)
        data_now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        return f'[{log_level.name}] [{data_now}] {text}'


class Logger:
    def __init__(self, filters_protocol: List[LogFilter], formatters_protocol: List[LogFormatter],
                 handlers_protocol: List[LogHandler]) -> None:
        check_protocols(filters_protocol, formatters_protocol, handlers_protocol)
        self.filters = filters_protocol
        self.formatters = formatters_protocol
        self.handlers = handlers_protocol

    def log(self, log_level: LogLevel, text: str) -> None:
        check_text(text)

        for filter_op in self.filters:
            if not filter_op.match(log_level, text):
                return

        formatted_text = text
        for formatter_op in self.formatters:
            formatted_text = formatter_op.format(log_level, text)

        for handler_op in self.handlers:
            handler_op.handle(log_level, formatted_text)

    def log_info(self, text: str) -> None:
        check_text(text)
        self.log(LogLevel.INFO, text)

    def log_warn(self, text: str) -> None:
        check_text(text)
        self.log(LogLevel.WARN, text)

    def log_error(self, text: str) -> None:
        check_text(text)
        self.log(LogLevel.ERROR, text)



filters = [LevelFilter(LogLevel.WARN), SimpleLogFilter("abc"), ReLogFilter("error|warn")]

formatters = [TextFormatter()]

handlers = [ConsoleHandler(), FileHandler("output.log"), SyslogHandler()]
#  SocketHandler(...)
#  FtpHandler(...)

logger = Logger(filters, formatters, handlers)

test_messages = [
    (LogLevel.INFO, "Это информационное сообщение"),
    (LogLevel.INFO, "Это информационное сообщение abc"),
    (LogLevel.INFO, "Это информационное сообщение abc warn"),
    (LogLevel.WARN, "Это информационное сообщение"),
    (LogLevel.WARN, "Это информационное сообщение abc"),
    (LogLevel.WARN, "Это информационное сообщение abc warn"),
    (LogLevel.ERROR, "Это информационное сообщение"),
    (LogLevel.ERROR, "Это информационное сообщение abc"),
    (LogLevel.ERROR, "Это информационное сообщение abc warn"),
]

for level, message in test_messages:
    print(f"Попытка записи: [{level.name}] {message}")
    logger.log(level, message)

logger.log_info("Информация через log_info()")
logger.log_warn("Предупреждение через log_warn()")
logger.log_error("Ошибка через log_error()")
