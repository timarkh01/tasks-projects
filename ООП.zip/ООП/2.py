from typing import Tuple
import time
from egfh import check_types, read_int_file, check_type_for_text


#reset_coord = '\033[0;0H'
reset_func = '\033[2J'


class Color:
    BLACK = '\033[30m'
    RED = '\033[31m'
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    BLUE = '\033[34m'
    MAGENTA = '\033[35m'
    CYAN = '\033[36m'
    WHITE = '\033[37m'
    RESET = '\033[0m'


class Console:
    def __init__(self, color: str, position: Tuple[int, int], symbol: str, int_file: str) -> None:
        check_types(color, position, symbol)
        self.color = color
        self.position = position
        self.symbol = symbol
        self.int_file = int_file

    @staticmethod
    def move_cursor(x: int, y: int) -> None:
        print(f'\033[{y};{x}H', end='')

    @staticmethod
    def clear() -> None:
        #print(reset_coord)
        print(reset_func)
        print(Color.RESET)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.clear()

    def print(self, text: str):
        self.print_s(text, self.color, self.position, self.symbol, self.int_file)

    @classmethod
    def print_s(cls, text: str, color: str, position: Tuple[int, int], symbol: str, int_file: str) -> None:
        check_types(color, position, symbol)
        check_type_for_text(text)
        print(f'{color}')
        int_info = read_int_file(int_file)
        x, y = position[0], position[1]
        height = int_info['Height']
        for letter in text:
            for i in range(height):
                cls.move_cursor(x, y + i)
                print(int_info['Letters'][letter][i].replace('*', symbol), end=' ')
            x += height + 1
        print(f'{Color.RESET}')

Console.print_s("ABD", Color.RED, (10, 3), "%", 'F:\Format5.json')
time.sleep(2)
Console.clear()

with Console(Color.GREEN, (2,2), "|", "F:\Format7.json") as p:
    p.print("ABS")
    time.sleep(2)
    p.clear()
    p.print("ABE")
    time.sleep(2)
    p.clear()
    p.print("AGJ")
    time.sleep(2)